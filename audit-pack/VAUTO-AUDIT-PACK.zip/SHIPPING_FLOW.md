# SHIPPING_FLOW.md
Source: `server/src/routes/shipping.ts`, `server/src/shipping/shipping-routing.ts`, `server/src/routes/escrow-billing.ts`.

## Status: **MOCK ONLY / SIMULATED**
Real Omniva/DPD/LP Express API integration — **NOT IMPLEMENTED**. No `OMNIVA_API_KEY`, `DPD_API_KEY` usage in server code. `render.yaml` does not define carrier env vars.

## Carrier flow (simulated)
1. Client requests lockers: `GET /api/shipping/lockers?city=...&provider=omniva|dpd|lp_express`.
2. Server returns synthetically generated lockers from `buildNationalLockers()` — one per LT city from hardcoded `LT_CITY_COORDS` (`shipping-routing.ts`).
3. Route estimate: `POST /api/shipping/route-estimate` — great-circle distance + `transitDaysFromDistance` heuristic. **No carrier API.**
4. Escrow label: `POST /api/escrow-billing/shipping-label` generates:
   - Random ID `${PROVIDER}-${random6}`
   - QR payload string
   - Lithuanian instruction text
   - Updates `escrow_transactions.shipping_label_id`, status → `label_sent`
5. Express 24h flow: `/api/ai/express-escrow-locker` + `/api/ai/process-express-escrow` (`ai/order-agent.ts`) — **MOCK** auto-confirm simulation.

## Tracking
- `escrow_transactions.tracking_code` — set from mock label flow.
- `courier_status`, `courier_provider` columns exist — updated in simulated express flow only.
- Real carrier webhook tracking — **NOT IMPLEMENTED**.

## Retries
- **NOT IMPLEMENTED** — no retry on label creation failure (synchronous single attempt).

## Fallbacks
- If no geo coords on listing, route estimate uses city centroid from hardcoded table.
- Provider selection is client-side enum only — no live carrier availability check.

## Failure points
| Point | Impact |
|-------|--------|
| User expects real label | Receives fake QR — **RISK** production trust |
| No carrier API keys | Health/readiness shows `shippingCarrierLive: false` (via verify scripts, not in `/api/health` features object directly) |
| Locker list stale | Static synthetic data never updates |
| Express escrow timer | In-memory/time-based sim — may not survive server restart |

## DB fields (escrow_transactions)
`shipping_provider`, `shipping_locker_id`, `shipping_locker_name`, `tracking_code`, `shipping_label_id`, `delivery_status`, `express_escrow_24h`, `delivered_to_locker_at`, `claim_deadline_at`, `courier_status`, `courier_provider`.

## Frontend mock
`src/lib/shipping/shipping-provider.ts` — client-side shipping helpers (**MOCK ONLY**).
`src/lib/escrow.ts` — `generateTrackingCode` in-memory.

## Blocker for production shipping
Configure real carrier APIs — **NOT IMPLEMENTED** in codebase. Stage 2 blocked on Omniva/DPD keys per prior health audit.
